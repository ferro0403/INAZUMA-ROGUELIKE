(function (global) {
  "use strict";

  function hashSeed(value) {
    let hash = 2166136261;
    const text = String(value);
    for (let index = 0; index < text.length; index += 1) {
      hash ^= text.charCodeAt(index);
      hash = Math.imul(hash, 16777619);
    }
    return hash >>> 0;
  }

  function randomFromSeed(seed) {
    let state = hashSeed(seed) || 1;
    return function random() {
      state += 0x6d2b79f5;
      let value = state;
      value = Math.imul(value ^ (value >>> 15), value | 1);
      value ^= value + Math.imul(value ^ (value >>> 7), value | 61);
      return ((value ^ (value >>> 14)) >>> 0) / 4294967296;
    };
  }

  function shuffle(items, random) {
    const result = items.slice();
    for (let index = result.length - 1; index > 0; index -= 1) {
      const target = Math.floor(random() * (index + 1));
      [result[index], result[target]] = [result[target], result[index]];
    }
    return result;
  }

  function makeRoleSequence(formation) {
    const requirements = formation.requirements;
    return [
      ...Array(requirements.GK || 0).fill("GK"),
      ...Array(requirements.DF || 0).fill("DF"),
      ...Array(requirements.MF || 0).fill("MF"),
      ...Array(requirements.FW || 0).fill("FW"),
    ];
  }

  function makeCandidates(players, role, excludedIds, seed) {
    const random = randomFromSeed(seed);
    const pool = players.filter(
      (player) =>
        String(player.position || player.normalizedRole).toUpperCase() === role &&
        !excludedIds.includes(String(player.playerId))
    );
    return shuffle(pool, random).slice(0, 3).map((player) => String(player.playerId));
  }

  function selectCandidates(available, random, count = 3) {
    return shuffle(available, random).slice(0, count);
  }

  function selectWeightedCandidates(available, random, categoryWeights = {}, count = 3) {
    const remaining = available.slice();
    const selected = [];
    while (remaining.length && selected.length < count) {
      const weighted = remaining.map((player) => ({
        player,
        weight: Math.max(0, Number(categoryWeights[player.category]) || 1),
      }));
      const total = weighted.reduce((sum, entry) => sum + entry.weight, 0);
      if (!total) break;
      let cursor = random() * total;
      const index = weighted.findIndex((entry) => {
        cursor -= entry.weight;
        return cursor <= 0;
      });
      const pickedIndex = index >= 0 ? index : weighted.length - 1;
      selected.push(weighted[pickedIndex].player);
      remaining.splice(pickedIndex, 1);
    }
    return selected;
  }

  function selectLegendaryCandidates(available, random, categoryRank, eliteCategory = "Elite", count = 3) {
    const initiallySelected = selectCandidates(available, random, count);
    const eliteRank = categoryRank(eliteCategory);
    if (initiallySelected.some((player) => categoryRank(player.category) >= eliteRank)) {
      return initiallySelected;
    }

    const selectedIds = new Set(initiallySelected.map((player) => String(player.playerId)));
    const guaranteedPool = available.filter(
      (player) => !selectedIds.has(String(player.playerId)) && categoryRank(player.category) >= eliteRank
    );
    if (!guaranteedPool.length) return initiallySelected;

    const guaranteed = selectCandidates(guaranteedPool, random, 1)[0];
    if (!guaranteed) return initiallySelected;

    const candidates = initiallySelected.slice(0, Math.max(0, count - 1));
    candidates.push(guaranteed);
    return shuffle(candidates, random);
  }

  function start(run, formation, players) {
    const roles = makeRoleSequence(formation);
    run.draft = {
      roles,
      step: 0,
      selectedIds: [],
      excludedIds: [],
      candidates: [],
    };
    run.phase = "draft";
    prepareStep(run, players);
    return run;
  }

  function prepareStep(run, players) {
    const draft = run.draft;
    if (draft.step >= draft.roles.length) return [];
    const role = draft.roles[draft.step];
    const candidates = makeCandidates(
      players,
      role,
      draft.excludedIds,
      `${run.runId}:draft:${draft.step}:${role}`
    );
    draft.candidates = candidates;
    draft.excludedIds.push(...candidates);
    return candidates;
  }

  function choose(run, playerId, players, formation) {
    const draft = run.draft;
    if (!draft.candidates.includes(String(playerId))) {
      throw new Error("This player is not part of the current draft choice");
    }
    draft.selectedIds.push(String(playerId));
    draft.step += 1;

    if (draft.step < draft.roles.length) {
      prepareStep(run, players);
      return false;
    }

    const selectedByRole = { GK: [], DF: [], MF: [], FW: [] };
    draft.selectedIds.forEach((id, index) => selectedByRole[draft.roles[index]].push(id));
    const lineup = formation.slotRoles.map((role) => selectedByRole[role].shift());
    run.roster = draft.selectedIds.map((id) => ({
      playerId: id,
      source: "free_agents",
      level: 0,
      equippedItem: null,
    }));
    run.lineup = lineup;
    run.bench = [];
    if (global.FiveVFive) {
      const byId = new Map(players.map((player) => [String(player.playerId), player]));
      global.FiveVFive.ensure(run, (id) => byId.get(String(id))?.position);
    }
    run.draft = null;
    run.phase = "squad";
    return true;
  }

  global.DraftEngine = {
    randomFromSeed,
    shuffle,
    makeRoleSequence,
    makeCandidates,
    selectCandidates,
    selectWeightedCandidates,
    selectLegendaryCandidates,
    start,
    prepareStep,
    choose,
  };
})(globalThis);
