"use strict";

const assert = require("assert");
const fs = require("fs");
const progression = require("../js/roguelike_progression.js");
const DevelopmentV2 = require("../js/development-v2.js");
const DevelopmentV3 = require("../js/development-v3.js");
const Migration = require("../js/development-v3-migration.js");
global.DevelopmentV2 = DevelopmentV2;
global.DevelopmentV3 = DevelopmentV3;
global.DevelopmentV3Migration = Migration;
global.InazumaProgression = progression;
const Runtime = require("../js/development-runtime.js");

const ratings = { attack: 6, control: 6, speed: 6, grit: 6, physical: 6, stamina: 6, defense: 6, save: 6 };
const database = { compactFormat: { levelMax: 20 }, players: [] };
for (const [index, role] of ["GK", "DF", "MF", "FW"].entries()) database.players.push({ playerId: `pr4-${role}`, name: role, position: role, category: "Normale", finalOverall: 74 + index, maxLevel: 20, ratings });
Runtime.registerDatabase("pr4-consumers", database);
const evolutionHistory = database.players.flatMap((player, index) => [
  { id: `receipt-${player.playerId}-1`, playerId: player.playerId, fromRarity: "Normale", toRarity: "Buono", fromPotential: player.finalOverall, toPotential: 75 + index, projectsConsumed: 0, cupsConsumed: 0, cupsConsumedBySource: {}, coinsConsumed: 0, timestamp: "2026-08-27T00:00:00.000Z" },
  { id: `receipt-${player.playerId}-2`, playerId: player.playerId, fromRarity: "Buono", toRarity: "Forte", fromPotential: 75 + index, toPotential: 80 + index, projectsConsumed: 0, cupsConsumed: 0, cupsConsumedBySource: {}, coinsConsumed: 0, timestamp: "2026-08-28T00:00:00.000Z" },
]);
const state = { schemaVersion: 7, coins: 0, cupsBySeason: {}, projects: {}, evolutionHistory, players: Object.fromEntries(database.players.map((player, index) => [player.playerId, { permanentTargetPotential: 80 + index, currentPermanentRarity: "Forte" }])) };
const snapshots = Runtime.buildRunSnapshot({ v2State: state, database });
const v3Run = { ...snapshots };

const expected = new Map();
for (const player of database.players) {
  const values = Array.from({ length: 21 }, (_, level) => Runtime.resolvePlayer(v3Run, player, level, database));
  expected.set(player.playerId, values);
  assert(values.every((value) => value.category === "Forte"), `${player.position} Lv0..Lv20 card/runtime rarity`);
}

const originalOptions = DevelopmentV2.optionsFromUpgrade;
DevelopmentV2.optionsFromUpgrade = () => { throw new Error("old permanent solver called"); };
try {
  delete v3Run.developmentPlayerSnapshot;
  for (const player of database.players) for (let level = 0; level <= 20; level += 1) {
    assert.deepStrictEqual(Runtime.resolvePlayer(v3Run, player, level, database), expected.get(player.playerId)[level], `${player.position}/Lv${level} ignores compatibility V2`);
  }
  const player = database.players[3];
  assert.strictEqual(Runtime.resolveEffectiveMetadata(v3Run, player, database).category, "Forte", "pull/trade/legendary metadata uses V3");
  const entry = { playerId: player.playerId, level: 5, potentialBoost: 3, currentOverallBoost: 3, potentialBoostApplications: [{ amount: 3, appliedLevel: 5, codexDeltas: { attack: 1 } }], equippedItem: { stat: "speed", bonus: 2 } };
  const permanent = Runtime.resolvePlayer(v3Run, player, 5, database);
  const roster = Runtime.resolveRosterPlayer(v3Run, player, entry, database);
  assert.strictEqual(roster.potential, permanent.potential + 3, "Intensive Training layers once above V3 permanent potential");
  assert.strictEqual(roster.overall, permanent.overall + 3, "Intensive Training layers once above V3 permanent overall");
  assert.strictEqual(roster.stats.attack, permanent.stats.attack + 10, "only run-local codex delta layers above materialized stats");
  assert.deepStrictEqual(entry.equippedItem, { stat: "speed", bonus: 2 }, "equipment is not consumed or changed by DevelopmentRuntime");
} finally { DevelopmentV2.optionsFromUpgrade = originalOptions; }

const legacyPlayer = database.players[0];
const legacyRun = { developmentPlayerSnapshot: { [legacyPlayer.playerId]: state.players[legacyPlayer.playerId] } };
assert.deepStrictEqual(
  Runtime.resolvePlayer(legacyRun, legacyPlayer, 7, database),
  progression.getPlayerAtLevel(legacyPlayer, 7, database, DevelopmentV2.optionsFromUpgrade(legacyPlayer, state.players[legacyPlayer.playerId])),
  "V2-only frozen runs retain exact playback"
);
const legacyEntries = [
  { name: "aggregate-only", entry: { potentialBoost: 6, currentOverallBoost: 6 } },
  { name: "normalized-legacy", entry: { potentialBoost: 6, currentOverallBoost: 6, potentialBoostApplications: [{ amount: 6, appliedLevel: 0, legacy: true }] } },
  { name: "permanent-plus-codex-training", entry: { potentialBoost: 9, currentOverallBoost: 9, potentialBoostApplications: [{ amount: 6, appliedLevel: 0, permanent: true }, { amount: 3, appliedLevel: 4, codexDeltas: { defense: 1 } }] } },
  { name: "run-local-without-codex", entry: { potentialBoost: 9, currentOverallBoost: 9, potentialBoostApplications: [{ amount: 6, appliedLevel: 0, permanent: true }, { amount: 3, appliedLevel: 4 }] } },
];
for (const { name, entry } of legacyEntries) for (let level = 0; level <= 20; level += 1) {
  const expectedLegacy = progression.getPlayerAtLevel(legacyPlayer, level, database, entry);
  assert.deepStrictEqual(Runtime.resolveRosterPlayer(legacyRun, legacyPlayer, { ...entry, level }, database), expectedLegacy, `${name}/Lv${level} preserves pre-PR4 roster playback`);
}

const v3TrainingPlayer = database.players[0];
const v3TrainingRun = Runtime.buildRunSnapshot({ v2State: state, database });
const emptyTrainingEntry = { playerId: v3TrainingPlayer.playerId, level: 20, potentialBoost: 0, currentOverallBoost: 0, potentialBoostApplications: [] };
const trainingPlan = Runtime.planIntensiveTraining(v3TrainingRun, v3TrainingPlayer, emptyTrainingEntry, 3, database);
assert.strictEqual(v3TrainingPlayer.finalOverall, 74, "training fixture starts at immutable BASE 74");
assert.strictEqual(trainingPlan.permanentPotential, 80, "planner starts from frozen V3 permanent 80");
assert.strictEqual(trainingPlan.targetOverall, 83, "V3 Intensive Training targets permanent 80 + 3, never BASE 74 + 3");
const trainedEntry = { ...emptyTrainingEntry, potentialBoost: 3, currentOverallBoost: 3, potentialBoostApplications: [{ amount: 3, appliedLevel: 20, codexDeltas: trainingPlan.codexDeltas }] };
const trained = Runtime.resolveRosterPlayer(v3TrainingRun, v3TrainingPlayer, trainedEntry, database);
const permanentAtMax = Runtime.resolvePlayer(v3TrainingRun, v3TrainingPlayer, 20, database);
const expectedRatings = { ...progression.toCodexRatings(permanentAtMax.stats) };
for (const [stat, delta] of Object.entries(trainingPlan.codexDeltas)) expectedRatings[stat] += delta;
assert.strictEqual(trained.potential, 83);
assert.strictEqual(trained.overall, 83);
assert.deepStrictEqual(progression.toCodexRatings(trained.stats), expectedRatings, "resolved stats are the exact Codex 80 -> 83 run-local delta");

const pr3CopiedEntry = { playerId: v3TrainingPlayer.playerId, level: 20, potentialBoost: 9, currentOverallBoost: 9, potentialBoostApplications: [{ amount: 6, appliedLevel: 0, permanent: true }, { amount: 3, appliedLevel: 20, codexDeltas: trainingPlan.codexDeltas }] };
assert.deepStrictEqual(Runtime.resolveRosterPlayer(v3TrainingRun, v3TrainingPlayer, pr3CopiedEntry, database), trained, "PR3 copied permanent fields are ignored while run-local training layers once");
const serializedRun = JSON.parse(JSON.stringify({ ...v3TrainingRun, roster: [trainedEntry], checkpoint: { developmentV3PlayerSnapshot: v3TrainingRun.developmentV3PlayerSnapshot, roster: [trainedEntry] } }));
assert.deepStrictEqual(Runtime.resolveRosterPlayer(serializedRun, v3TrainingPlayer, serializedRun.roster[0], database), trained, "save/refresh/load preserves V3 runtime playback");
assert.deepStrictEqual(Runtime.resolveRosterPlayer(serializedRun.checkpoint, v3TrainingPlayer, serializedRun.checkpoint.roster[0], database), trained, "checkpoint restoration preserves V3 runtime playback");

function runAtPermanent(target) {
  const category = progression.categoryForPotential(target, v3TrainingPlayer.category, database);
  const profile = DevelopmentV3.materializeProfile({ basePlayer: v3TrainingPlayer, targetPotential: target, database, category, progression });
  return { developmentV3PlayerSnapshot: { schemaVersion: 1, profileFormatVersion: DevelopmentV3.PROFILE_FORMAT_VERSION, players: { [v3TrainingPlayer.playerId]: { profile } } } };
}
const nearCapRun = runAtPermanent(98);
const oversizedEntry = { playerId: v3TrainingPlayer.playerId, level: 20, potentialBoost: 3, currentOverallBoost: 3, potentialBoostApplications: [{ amount: 3, appliedLevel: 20, codexDeltas: { attack: 1 } }] };
const oversizedBefore = JSON.stringify(oversizedEntry);
const nearCapState = Runtime.trainingState(nearCapRun, v3TrainingPlayer, oversizedEntry, database);
assert.strictEqual(nearCapState.permanentPotential, 98);
assert.strictEqual(nearCapState.maxLocalBoost, 1);
assert.strictEqual(nearCapState.currentLocalBoost, 1);
assert.strictEqual(nearCapState.applications[0].amount, 1, "oversized saved local application canonicalizes in memory to the one available point");
assert.strictEqual(JSON.stringify(oversizedEntry), oversizedBefore, "runtime normalization does not mutate saved bytes or the frozen snapshot");
const nearCapPlan = Runtime.planIntensiveTraining(nearCapRun, v3TrainingPlayer, { potentialBoost: 0, currentOverallBoost: 0, potentialBoostApplications: [] }, 3, database);
assert.strictEqual(nearCapPlan.appliedBoost, 1);
assert.strictEqual(nearCapPlan.targetOverall, 99, "BASE 74 -> permanent 98 -> requested +3 plans only +1");
const appliedNearCap = { playerId: v3TrainingPlayer.playerId, level: 20, potentialBoost: nearCapPlan.appliedBoost, currentOverallBoost: nearCapPlan.appliedBoost, potentialBoostApplications: [{ amount: nearCapPlan.appliedBoost, appliedLevel: 20, codexDeltas: nearCapPlan.codexDeltas }] };
assert.strictEqual(appliedNearCap.potentialBoostApplications[0].amount, 1, "stored application records the applied +1, never requested +3");
assert.strictEqual(Runtime.resolveRosterPlayer(nearCapRun, v3TrainingPlayer, appliedNearCap, database).potential, 99);
const maxedState = Runtime.trainingState(nearCapRun, v3TrainingPlayer, appliedNearCap, database);
assert.strictEqual(maxedState.remainingBoost, 0);
assert.strictEqual(Runtime.planIntensiveTraining(nearCapRun, v3TrainingPlayer, appliedNearCap, 3, database).appliedBoost, 0, "second item at 99 is rejected before mutation/consumption");

const ninetyFiveRun = runAtPermanent(95);
const existingTwo = { potentialBoost: 2, currentOverallBoost: 2, potentialBoostApplications: [{ amount: 2, appliedLevel: 10, codexDeltas: { attack: 1 } }] };
const ninetyFiveState = Runtime.trainingState(ninetyFiveRun, v3TrainingPlayer, existingTwo, database);
assert.strictEqual(ninetyFiveState.remainingBoost, 2);
const ninetyFivePlan = Runtime.planIntensiveTraining(ninetyFiveRun, v3TrainingPlayer, existingTwo, 3, database);
assert.strictEqual(ninetyFivePlan.appliedBoost, 2);
assert.strictEqual(ninetyFivePlan.targetOverall, 99, "permanent 95 + existing 2 + requested 3 applies only remaining 2");

const collisionV3High = runAtPermanent(95);
const profileEighty = { ...v3TrainingPlayer, position: "MF", normalizedRole: "MF", finalOverall: 80, category: "Forte", ratings: { attack: 5, control: 8, speed: 7, grit: 7, physical: 5, stamina: 8, defense: 6, save: 1 }, activeProfileId: "same-player@profile-80", activeRoleVariantId: "mf" };
const profileEntry = { playerId: v3TrainingPlayer.playerId, activeProfileId: profileEighty.activeProfileId, activeRoleVariantId: "mf", potentialBoost: 0, currentOverallBoost: 0, potentialBoostApplications: [] };
const providedMode = { permanentMode: "provided-base" };
const collisionState = Runtime.trainingState(collisionV3High, profileEighty, profileEntry, database, providedMode);
assert.strictEqual(collisionState.permanentPotential, 80, "profile-aware baseline wins over same-playerId V3 95");
assert.strictEqual(collisionState.maxLocalBoost, 19);
const collisionPlan = Runtime.planIntensiveTraining(collisionV3High, profileEighty, profileEntry, 3, database, providedMode);
assert.strictEqual(collisionPlan.targetOverall, 83);
assert.strictEqual(collisionPlan.appliedBoost, 3);
assert.strictEqual(profileEighty.position, "MF");
assert.strictEqual(profileEighty.activeProfileId, "same-player@profile-80", "profile role and identity remain the supplied permanent baseline");

const collisionV3Low = runAtPermanent(80);
const profileNinetyFive = { ...profileEighty, finalOverall: 95, category: "Leggenda", activeProfileId: "same-player@profile-95" };
const reverseState = Runtime.trainingState(collisionV3Low, profileNinetyFive, profileEntry, database, providedMode);
assert.strictEqual(reverseState.permanentPotential, 95, "profile-aware baseline wins over same-playerId V3 80");
assert.strictEqual(reverseState.maxLocalBoost, 4);
assert.strictEqual(Runtime.planIntensiveTraining(collisionV3Low, profileNinetyFive, profileEntry, 3, database, providedMode).targetOverall, 98);

const collisionOversized = { ...profileEntry, potentialBoost: 10, currentOverallBoost: 10, potentialBoostApplications: [{ amount: 10, appliedLevel: 0, legacy: true }] };
const collisionReloaded = JSON.parse(JSON.stringify(collisionOversized));
const collisionReloadedState = Runtime.trainingState(JSON.parse(JSON.stringify(collisionV3High)), profileEighty, collisionReloaded, database, providedMode);
assert.strictEqual(collisionReloadedState.currentLocalBoost, 10, "save/load normalization uses profile capacity 19, not colliding V3 capacity 4");
assert.deepStrictEqual(collisionReloaded, collisionOversized, "profile-aware normalization is read-only");
const incompatible = Runtime.buildRunSnapshot({ v2State: state, database });
incompatible.developmentPlayerSnapshot[legacyPlayer.playerId].permanentTargetPotential = 99;
assert.strictEqual(Runtime.resolvePlayer(incompatible, legacyPlayer, 20, database).potential, 80, "V3 has precedence over incompatible V2 compatibility data");
assert.throws(() => Runtime.resolvePlayer({ developmentV3PlayerSnapshot: { schemaVersion: 1, profileFormatVersion: 1, players: { bad: { profile: {} } } } }, legacyPlayer, 0, database), /development-v3-snapshot-invalid/, "malformed claimed V3 fails deterministically");

const app = fs.readFileSync("js/app.js", "utf8");
const draft = fs.readFileSync("js/draft.js", "utf8");
for (const [file, source] of [["js/app.js", app], ["js/draft.js", draft]]) {
  assert(!/developmentPlayerSnapshot/.test(source), `${file} must not interpret the legacy snapshot`);
  assert(!/DevelopmentV2\.optionsFromUpgrade/.test(source.replace(/function albumPlayerView[\s\S]*?\n  }/, "").replace(/function renderEvolutionConfirmation[\s\S]*?\n  }/, "")), `${file} must not resolve run Development through V2`);
}
assert.match(app, /DevelopmentRuntime\.resolvePlayer\(run, player/, "cards and pull choices use DevelopmentRuntime");
assert.match(app, /DevelopmentRuntime\.resolveRosterPlayer/, "roster, lineup and match inputs share the runtime boundary");
assert.match(app, /DevelopmentRuntime\.resolveEffectiveMetadata/, "pull, legendary and trade eligibility use runtime metadata");
assert.match(app, /DevelopmentRuntime\.planIntensiveTraining\(current,trainingBase,currentEntry,addedBoost,currentProfileAware\?seasonDb:freeAgentsDb,currentProfileAware\?\{permanentMode:"provided-base"\}:undefined\)/, "production Intensive Training uses the real centralized runtime planner and profile-aware mode");
assert.match(app, /runtimeTrainingState\(entry, run\)/, "roster normalization uses Runtime-derived training capacity");
assert.match(app, /const training = runtimeTrainingState\(entry\)/, "item application uses the same Runtime-derived capacity");
assert.doesNotMatch(app, /99\s*-\s*activeBasePotential\(entry\)/, "V3 training capacity is never derived from immutable BASE in app.js");
assert.match(app, /profileAware \? \{ permanentMode: "provided-base" \} : undefined/, "profile-aware normalization bypasses colliding Development snapshots");

console.log("development-runtime-consumers-test: V3/V2/base, roles, zero-solver, roster/training, pull/trade/legendary static guard OK");
